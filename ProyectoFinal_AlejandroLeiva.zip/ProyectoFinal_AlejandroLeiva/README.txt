Desarrollar una WEB Django con patrón MVT subida a Github.
Se debe entregar

Link de GitHub con el proyecto totalmente subido a la plataforma.
Proyecto Web Django con patrón MVT que incluya:
Herencia de HTML.
Por lo menos 3 clases en models.
Un formulario para insertar datos a todas las clases de tu models.
Readme que indique el orden en el que se prueban las cosas y/o donde están las funcionalidades.

Link al repositorio de GitHub con el nombre “Tercera pre-entrega+Apellido”.




1. Se creo la aplicacion CORE

2. Informacion de ususario admin:
    ID: admin
    PASSW: 1234

3. Se crearon 3 modelos: Pais, Producto y Cliente

4. Al registrar los clientes con el usuario admin, se veran reflejados en pagina principal.

5.