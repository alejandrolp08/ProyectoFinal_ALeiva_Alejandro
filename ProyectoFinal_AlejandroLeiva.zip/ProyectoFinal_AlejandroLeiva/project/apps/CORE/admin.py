from django.contrib import admin

# Register your models here.

admin.site.site_header = "Tu tienda de Figuras"
admin.site.site_title = "Home"